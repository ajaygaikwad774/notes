
install.packages(c("RMySQL"), dependencies = TRUE)
