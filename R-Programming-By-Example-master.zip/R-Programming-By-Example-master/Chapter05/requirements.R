
install.packages(c(
    "ggplot2",
    "viridis",
    "ggExtra",
    "threejs",
    "leaflet",
    "plotly",
    "rgdal",
    "maps",
    "plyr",
    "rgl"
), dependencies = TRUE)
