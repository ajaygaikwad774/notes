
This `results/` directoy is meant to hold the script outputs.
