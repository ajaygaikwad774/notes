
library(devtools)
install_github("vqv/ggbiplot")

install.packages(c(
    "viridis",
    "ggplot2",
    "corrplot",
    "progress"
), dependencies = TRUE)
