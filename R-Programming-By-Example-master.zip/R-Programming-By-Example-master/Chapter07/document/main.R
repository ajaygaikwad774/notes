#
# Chapter 07 - Developing Automatic Sales Reports : Document
#
# R Programming by Example
# Omar Trejo Navarro
# Packt Publishing
# Mexico City
# 2017
#
