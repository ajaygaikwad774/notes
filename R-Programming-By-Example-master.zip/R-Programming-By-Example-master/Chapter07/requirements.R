
install.packages(c(
    "bookdown",
    "rmarkdown"
), dependencies = TRUE)
